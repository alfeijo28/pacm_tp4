void ghosts_move(unsigned char &, unsigned char &, unsigned char &, unsigned char &, unsigned char &, unsigned char &, 
	unsigned char &, unsigned char &, bool [], bool [], bool [], bool [], bool &, bool &, bool &, bool &, int, int);
bool possible(bool [], bool [], unsigned char);
void move(unsigned char &, unsigned char , bool [], bool &);
void looking(bool [], char []);
bool killed(unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, int, int);
bool kill(unsigned char &, unsigned char &, unsigned char &, unsigned char &, unsigned char &, unsigned char &, unsigned char &, unsigned char &, 
	int, int, bool &, bool &, bool &, bool &, bool);